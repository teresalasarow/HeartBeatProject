package rmi.interfaces;

public interface IHeartBeatObserver extends java.rmi.Remote  {
	
	public void update(int heartrate) //hier kann irgendwie auch gleich setHeartBeatState() eingesetzt werden oder ähnliche. Das habe ich nicht richtig verstanden. 
			throws java.rmi.RemoteException;
 //update(HeartBeat Observable, Object updateMSG);
}
